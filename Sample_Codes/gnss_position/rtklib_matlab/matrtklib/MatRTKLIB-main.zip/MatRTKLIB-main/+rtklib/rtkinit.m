% RTKINIT Initialize RTK control struct
%  rtk = RTKINIT(opt)
%
% Inputs: 
%    opt : 1x1, option struct
%
% Outputs:
%    rtk : 1x1, rtk control struct
%
% Author: 
%    Taro Suzuki
