% OUTSOL Output RTKLIB solution file
%  OUTSOL(file, solbuf)
%
% Inputs: 
%    file   : 1x1, file path {???.pos}
%    solbuf : 1x1, solution buffer struct
% 
% Author: 
%    Taro Suzuki
