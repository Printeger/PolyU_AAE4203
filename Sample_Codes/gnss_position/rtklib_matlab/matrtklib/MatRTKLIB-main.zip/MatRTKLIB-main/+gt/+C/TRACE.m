classdef TRACE < double
    enumeration
        TRACE_OFF(0)
        TRACE_LV1(1)
        TRACE_LV2(2)
        TRACE_LV3(3)
        TRACE_LV4(4)
        TRACE_LV5(5)
    end
end