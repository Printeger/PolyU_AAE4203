classdef HIGHTF < double
    enumeration
        HIGHTF_ELLI(0)    % ellipsoidal
        HIGHTF_GEOD(1)    % geodetic
    end
end