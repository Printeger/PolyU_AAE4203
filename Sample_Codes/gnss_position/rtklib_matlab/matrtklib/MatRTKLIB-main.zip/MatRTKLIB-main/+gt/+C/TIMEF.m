classdef TIMEF < double
    enumeration
        TIMEF_TOW(0) % TOW
        TIMEF_HMS(1) % hh:mm:ss
    end
end