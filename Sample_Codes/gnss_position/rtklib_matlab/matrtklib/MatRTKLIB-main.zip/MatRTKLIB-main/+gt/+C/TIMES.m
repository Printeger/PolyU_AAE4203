classdef TIMES < double
    enumeration
        TIMES_GPST(0) % time system: gps time
        TIMES_UTC (1) % time system: utc
        TIMES_JST (2) % time system: jst
    end
end