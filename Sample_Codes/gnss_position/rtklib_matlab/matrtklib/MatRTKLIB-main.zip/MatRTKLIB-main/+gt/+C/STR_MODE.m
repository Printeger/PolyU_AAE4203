classdef STR_MODE < double
    enumeration
        STR_MODE_R (1) % stream mode: read
        STR_MODE_W (2) % stream mode: write
        STR_MODE_RW(3) % stream mode: read/write
    end
end