classdef DEGF < double
    enumeration
        DEGF_DEG(0)       % degree
        DEGF_DMS(1)       % degree-minute-second
    end
end