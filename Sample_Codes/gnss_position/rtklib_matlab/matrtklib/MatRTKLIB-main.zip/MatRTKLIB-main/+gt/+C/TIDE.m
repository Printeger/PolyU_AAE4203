classdef TIDE < double
    enumeration
        TIDE_OFF(0)       % OFF
        TIDE_ON (1)       % ON
        TIDE_OTL(2)       % OTL
    end
end