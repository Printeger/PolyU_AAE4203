classdef SWITCH < double
    enumeration
        OFF(0) % OFF
        ON (1) % ON
    end
end