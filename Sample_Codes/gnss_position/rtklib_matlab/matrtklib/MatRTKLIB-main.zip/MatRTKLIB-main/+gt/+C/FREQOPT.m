classdef FREQOPT < double
    enumeration
        FREQOPT_L1    (1) % L1
        FREQOPT_L12   (2) % L1+2
        FREQOPT_L125  (3) % L1+2+5
        FREQOPT_L1256 (4) % L1+2+5+6
        FREQOPT_L12567(5) % L1+2+5+6+7
    end
end